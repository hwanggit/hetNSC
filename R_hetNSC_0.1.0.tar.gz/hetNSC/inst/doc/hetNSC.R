## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")

## -----------------------------------------------------------------------------
library(hetNSC)
hnsc_methods()[, c("label", "method", "variance")]

## -----------------------------------------------------------------------------
set.seed(8900)
dat <- simulate_hetero_data(ntr1 = 15, ntr2 = 20, nte1 = 50, nte2 = 50,
                            p = 1000, a = 14)
dim(dat$xtr)
table(dat$ytr)

## -----------------------------------------------------------------------------
set.seed(1)
fit <- hnsc(dat$xtr, dat$ytr, method = "HTh3")
fit

pred <- predict(fit, dat$xte)
mean(pred != dat$yte)                      # test error
head(predict(fit, dat$xte, type = "posterior"))
head(fit$selected.genes)                    # genes used by the classifier

## -----------------------------------------------------------------------------
set.seed(1)
fit0 <- hnsc(dat$xtr, dat$ytr, method = "hard", variance = "homo")
mean(predict(fit0, dat$xte) != dat$yte)

## -----------------------------------------------------------------------------
tr <- hnsc_train(dat$xtr, dat$ytr, method = "OTh3")
set.seed(2)
cv <- hnsc_cv(tr, dat$xtr, dat$ytr)
head(data.frame(threshold = cv$threshold, genes = cv$size, cv.error = cv$error))

set.seed(2)
sel <- hnsc_select(dat$xtr, dat$ytr, method = "OTh3")
sel

## -----------------------------------------------------------------------------
res <- compare_nsc(dat$xtr, dat$ytr, dat$xte, dat$yte, n.runs = 2,
                   thresholding = c("hard", "order"), verbose = FALSE)
res
recall_table(res)

